# Port Authority Vehicle Data Aggregation

This app aggregates real time vehicle data from the Port Authority API, and provides access to the data through a simple API. The idea behind the aggregation of this data is that historical delay data could be aggregated to predict future delays as well as determine routes currently delayed that are not typically delayed.

It consists of a worker service which retrieves data from the Port Authority API and stores the data, and an API service which provides access to the aggregated data.

# API

The api consists of a single endpoint which returns vehicle data in the following format:

```
{
  data: [
    VehicleState {
      vehicleId: String - Transit vehicle identifier,
      timestamp: Date - Date time of the vehicle data,
      route: String - Vehicle route,
      delayed: Boolean - Is vehicle delayed?,
      location: Map {
        lat: String - Latitude,
        lon: String - Longitude
      },
      heading: String - Directional heading in degrees,
      speed: Number - Speed in mph
    },
    ...
  ]
}
```

The api allows querying by vehicleId, timestamp, route, delayed status, as well as setting a limit of results.

## Examples



# Infrastructure

The services are developed to be run serverless on AWS Lambda and connect to AWS DynamoDB as a data store.
# Setup

```
npm install

npm run test-worker
npm run test-service

```
# Next Steps

-
