# TO DO
- create lambda which retrieves bus data and shoves into dynamodb
  - create shared dynamoose model
  - send a single request to port authority api
  - take each prediction in the response and push to dynamo
- cron which triggers lambda to run every 10 min

- create lambda to retrieve data from dynamodb
