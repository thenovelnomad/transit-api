module.exports = {
  db: {
    host: 'DB_HOST',
    port: 'DB_PORT'
  },
  busApi: {
    baseUrl: 'API_URL',
    apiKey: 'API_KEY'
  }
}
