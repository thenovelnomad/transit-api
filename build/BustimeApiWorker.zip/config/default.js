module.exports = {
  db: {
    host: '127.0.0.1',
    port: 4567
  },
  busApi: {
    baseUrl: 'https://realtime.portauthority.org',
    apiKey: '',
    routes: [ 4, 20 ]
  }
}
